const products=[
{id:1,name:'Arabica Coffee',price:320,icon:'☕',stock:24},{id:2,name:'Fresh Milk 500ml',price:75,icon:'🥛',stock:18},
{id:3,name:'Mineral Water',price:60,icon:'💧',stock:40},{id:4,name:'White Bread',price:65,icon:'🍞',stock:12},
{id:5,name:'Potato Crisps',price:120,icon:'🥔',stock:16},{id:6,name:'Orange Juice',price:180,icon:'🧃',stock:9},
{id:7,name:'Chocolate Bar',price:100,icon:'🍫',stock:21},{id:8,name:'Cooking Oil 1L',price:280,icon:'🫗',stock:7}
];
let cart=[], sales=JSON.parse(localStorage.getItem('posSales')||'[]');
const money=n=>'KSh '+n.toLocaleString();
document.getElementById('dateText').textContent=new Date().toLocaleDateString('en-KE',{weekday:'long',year:'numeric',month:'long',day:'numeric'});
function showPage(page){document.querySelectorAll('.page').forEach(x=>x.classList.add('hidden'));document.getElementById(page).classList.remove('hidden');document.querySelectorAll('.nav-item').forEach(x=>x.classList.toggle('active',x.dataset.page===page));document.getElementById('pageTitle').textContent=page[0].toUpperCase()+page.slice(1);if(page==='products')renderProducts();if(page==='sales')renderSales();}
document.querySelectorAll('.nav-item[data-page]').forEach(b=>b.onclick=()=>showPage(b.dataset.page));
function addToCart(id){const p=products.find(x=>x.id===id), item=cart.find(x=>x.id===id);if(item)item.qty++;else cart.push({...p,qty:1});renderCart();toast(p.name+' added to sale');}
function renderProducts(){const q=(document.getElementById('search')?.value||'').toLowerCase();document.getElementById('productGrid').innerHTML=products.filter(p=>p.name.toLowerCase().includes(q)).map(p=>`<div class="product" onclick="addToCart(${p.id})"><div class="product-icon">${p.icon}</div><b>${p.name}</b><div class="price">${money(p.price)}</div><div class="stock">${p.stock} in stock</div></div>`).join('');renderCart();}
function renderCart(){const el=document.getElementById('cartItems');el.innerHTML=cart.length?cart.map(i=>`<div class="cart-row"><div><b>${i.name}</b><div class="qty"><button onclick="event.stopPropagation();changeQty(${i.id},-1)">−</button>${i.qty}<button onclick="event.stopPropagation();changeQty(${i.id},1)">+</button></div></div><b>${money(i.price*i.qty)}</b></div>`).join(''):'<div class="empty" style="padding:35px 10px">Add products to begin</div>';document.getElementById('cartTotal').textContent=money(cart.reduce((a,i)=>a+i.price*i.qty,0));}
function changeQty(id,d){const i=cart.find(x=>x.id===id);if(!i)return;i.qty+=d;if(i.qty<=0)cart=cart.filter(x=>x.id!==id);renderCart()}
function clearCart(){cart=[];renderCart()}
function checkout(){if(!cart.length)return toast('Add a product first');const total=cart.reduce((a,i)=>a+i.price*i.qty,0);sales.unshift({id:'POS-'+String(Date.now()).slice(-6),date:new Date().toLocaleString(),items:cart.reduce((a,i)=>a+i.qty,0),total});localStorage.setItem('posSales',JSON.stringify(sales));cart=[];renderCart();updateStats();toast('Sale completed — '+money(total));}
function renderSales(){document.getElementById('salesTable').innerHTML=sales.length?sales.map(s=>`<tr><td><b>${s.id}</b></td><td>${s.date}</td><td>${s.items}</td><td>Cash</td><td><b>${money(s.total)}</b></td></tr>`).join(''):'<tr><td colspan="5" class="empty">No sales yet</td></tr>'}
function updateStats(){document.getElementById('todaySales').textContent=money(sales.reduce((a,s)=>a+s.total,0));document.getElementById('todayTransactions').textContent=sales.length;document.getElementById('productCount').textContent=products.length}
function renderDashboard(){document.getElementById('quickGrid').innerHTML=products.slice(0,4).map(p=>`<div class="quick" onclick="showPage('products');addToCart(${p.id})"><b>${p.icon} ${p.name}</b><span>${money(p.price)} · ${p.stock} available</span></div>`).join('');document.getElementById('recentSales').innerHTML=sales.slice(0,5).map(s=>`<div class="cart-row"><span>${s.id}<br><small>${s.date}</small></span><b>${money(s.total)}</b></div>`).join('')||'<div class="empty" style="padding:30px 5px">No sales yet</div>';updateStats()}
function addDemoProduct(){toast('Product editor can be connected to your database next');}
function toast(msg){const t=document.getElementById('toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2200)}
renderDashboard();renderProducts();
