# Point of Sale Frontend

A responsive POS frontend with:
- Dashboard
- Product catalogue and search
- Shopping cart
- Checkout flow
- Sales history
- Local browser persistence
- Responsive desktop/mobile layout

Open `index.html` directly for a static preview, or deploy the folder to Vercel as a static site.

The frontend currently uses demo products and localStorage. A backend/database can be connected later for authentication, inventory, customers, receipts, and real payments.
